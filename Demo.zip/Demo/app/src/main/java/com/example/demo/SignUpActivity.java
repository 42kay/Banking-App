package com.example.demo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

public class SignUpActivity extends AppCompatActivity {



    private Button eSignUp;
    TextView AlreadyHaveAccount;
    private EditText etName;
    private  EditText etPassword;


    private TextView etAccountNumber;

    private static final Pattern  Password_Pattern=
            Pattern.compile("^" +
                    //"(?=.*[0-9])" +         //at least 1 digit
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        etName = findViewById(R.id.etName);
        etPassword=findViewById(R.id.etPassword);
        etAccountNumber=findViewById(R.id.etAccountNumber);
        eSignUp=findViewById(R.id.btnSignUp);
        AlreadyHaveAccount=findViewById(R.id.AlreadyHaveAccount);



        eSignUp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this, MainActivity.class));

//                private boolean validateUsername (); {
////            TextView etName = null;
//                    assert etName != null;
//                    String usernameInput = etName.getText().toString().trim();
//
//                    if (usernameInput.isEmpty()) {
//                        etName.setError("Field can't be empty");
//                        return false;
//                    } else if (usernameInput.length() > 15) {
//                        etName.setError("Username too long");
//                        return false;
//                    } else {
//                        etName.setError(null);
//                        return true;
//                    }
//                }
//                private boolean validatePassword () {
//                    String passwordInput = etPassword.getText().toString().trim();
//
//                    if (passwordInput.isEmpty()) {
//                        etPassword.setError("Field can't be empty");
//                        return false;
//                    } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
//                        etPassword.setError("Password too weak");
//                        return false;
//                    } else {
//                        etPassword.setError(null);
//                        return true;
//                    }
//                }
//                public void confirmInput(View v) {
//                    if (!validateEmail() | !validateUsername() | !validatePassword()) {
//                        return;
//                    }
//
//                    String input = "Email: " + etAccountNumber.getText().toString();
//                    input += "\n";
//                    input += "Username: " + etUsername.getText().toString();
//                    input += "\n";
//                    input += "Password: " + etPassword.getText().toString();
//
//                    Toast.makeText(this, input, Toast.LENGTH_SHORT).show();
//                }

            }
        });
        AlreadyHaveAccount.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this,MainActivity.class));

            }
        });



    }
}