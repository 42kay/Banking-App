package com.example.demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Cheque_to_Savings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheque_to_savings);
    }
}