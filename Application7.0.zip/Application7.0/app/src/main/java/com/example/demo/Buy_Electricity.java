package com.example.demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Buy_Electricity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_electricity);

        EditText editTxtName = findViewById(R.id.dtTxtName);
    }

    public void onBtnClick (View view){
        TextView txtHello = findViewById(R.id.txtMessage);
        txtHello.setText("Hello");
    }
}